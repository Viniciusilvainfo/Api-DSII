const axios = require('axios');
const { buscarCampeonato, pesquisaCampeonato } = require('../apifutebol/futebol');

class PessoaController {

    async inicial(req, res) {
        // integracao 
        const campeonato = await buscarCampeonato();
        try {
            var id = campeonato[0].campeonato_id;
        }catch(error) {
            console.log(error);
        }
        try {
            const meuCampeonato = await pesquisaCampeonato(id);
            return res.render('pessoas', { meuCampeonato: meuCampeonato });
        }catch(error) {
            console.log(error);
        }
    }

}

module.exports = { PessoaController }