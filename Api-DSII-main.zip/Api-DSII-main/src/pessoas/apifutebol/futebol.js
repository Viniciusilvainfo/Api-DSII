const { default: axios } = require("axios");

const pesquisaCampeonato = async function(id) {
    URL = "https://api.api-futebol.com.br/v1/campeonatos/" + id + "/tabela";
    try {
        const resposta = await axios.get(URL, {
            headers: {
                authorization: "Bearer test_7ed3dc5bc47b2ee8e00c0241c28205"
            }
        });
        return resposta.data;
    } catch (error) {
        console.log(error)
    }
}

const buscarCampeonato = async function() {

    URL = 'https://api.api-futebol.com.br/v1/campeonatos';
    try {
        const resposta = await axios.get(URL, {
            headers: {
                authorization: "Bearer test_7ed3dc5bc47b2ee8e00c0241c28205"
            }
        });
        return resposta.data;
    } catch (error) {
        console.log(error);
    }
}

module.exports = { pesquisaCampeonato, buscarCampeonato }